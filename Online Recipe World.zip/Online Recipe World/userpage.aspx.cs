﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
public partial class userpage : System.Web.UI.Page
{
    StringBuilder htmlTable2 = new StringBuilder();
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection myconn;
        SqlCommand mycomm;
        myconn = new SqlConnection(ConfigurationManager.ConnectionStrings["cmd"].ConnectionString);
        string q = "select * from addcat";
        mycomm = new SqlCommand(q, myconn);
        myconn.Open();
        SqlDataReader articleReader = mycomm.ExecuteReader();
        if (articleReader.HasRows)
        {
            while (articleReader.Read())
            {
                htmlTable2.Append("<li>");
                htmlTable2.Append("<div class='banner-info1-grid'><a href='displaysubcat.aspx?cid=" + articleReader["catid"].ToString() + "'><img src='pics/" + articleReader["categorypic"].ToString() + "' alt=''  width='250' height='225' /></a><a href='displaysubcat.aspx?cid=" + articleReader["catid"].ToString() + "'><h3>" + articleReader["categoryname"].ToString() + "</h3></a></div>");
                htmlTable2.Append("</li>");
            }
            PlaceHolder1.Controls.Add(new Literal { Text = htmlTable2.ToString() });
            myconn.Close();
            articleReader.Close();
            articleReader.Dispose();
        }
        else
        {
            Response.Write("No Cats");
        }
        
    }
}