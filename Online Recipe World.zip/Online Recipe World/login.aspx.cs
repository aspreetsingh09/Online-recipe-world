﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlConnection myconn;
        SqlCommand mycomm;
        
        myconn = new SqlConnection(ConfigurationManager.ConnectionStrings["cmd"].ConnectionString);
        string q = "select * from signup where username=@un and password=@pass";
        mycomm = new SqlCommand(q, myconn);
        mycomm.Parameters.AddWithValue("@un", TextBox1.Text);
        mycomm.Parameters.AddWithValue("@pass", TextBox2.Text);
        myconn.Open();
        SqlDataReader myreader ;
        myreader = mycomm.ExecuteReader();
        if (myreader.HasRows == true)
        {
            myreader.Read();
            Session.Add("n", myreader["name"].ToString());
            Session.Add("uname",myreader["username"].ToString());
            if (myreader["usertype"].ToString().ToLower() == "admin")
            {
                myconn.Close();
                Session.Add("ad", "admin");
                Response.Redirect("adminpanel.aspx");
            }
            else
            {
                myconn.Close();

                if (Request.QueryString["returnurl"] != null)
                {
                    Response.Redirect(Request.QueryString["returnurl"]);
                }
                else
                {
                    Response.Redirect("userpage.aspx");
                }
            }
        }
            else
            {
                Label1.Text="Incorrect username/password";
            }
        }

    }
