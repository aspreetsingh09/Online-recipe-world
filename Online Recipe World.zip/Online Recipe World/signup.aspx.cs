﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class signup : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlConnection myconn;
        SqlCommand mycomm;
        myconn = new SqlConnection(ConfigurationManager.ConnectionStrings["cmd"].ConnectionString);
        string q = "insert into signup values(@n,@add,@ct,@st,@ph,@un,@pass,@gen,@con,@utype)";
        mycomm = new SqlCommand(q, myconn);
        mycomm.Parameters.AddWithValue("@n", TextBox1.Text);
        mycomm.Parameters.AddWithValue("@add", TextBox2.Text);
        mycomm.Parameters.AddWithValue("@ct", TextBox3.Text);
        mycomm.Parameters.AddWithValue("@st", TextBox4.Text);
        mycomm.Parameters.AddWithValue("@ph", TextBox5.Text);
        mycomm.Parameters.AddWithValue("@un", TextBox6.Text);
        mycomm.Parameters.AddWithValue("@pass", TextBox7.Text);
        mycomm.Parameters.AddWithValue("@gen", RadioButtonList1.SelectedItem.Text);
        mycomm.Parameters.AddWithValue("@con", DropDownList1.SelectedItem.Text);
        mycomm.Parameters.AddWithValue("@utype","normal");
        myconn.Open();
        int res = mycomm.ExecuteNonQuery();
        myconn.Close();
        if (res == 1)
        {
            Response.Redirect("thnx.aspx");
        }
        else
        {
            Label1.Text = "some errors are occured";
        }
    }
}