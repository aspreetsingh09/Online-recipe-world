﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class feedback : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlConnection myconn;
        SqlCommand mycomm;
        myconn = new SqlConnection(ConfigurationManager.ConnectionStrings["cmd"].ConnectionString);
        string q = "insert into feedback values(@n,@emid,@ph,@wo,@wd,@mr,@si,@sugg,@msgdt)";
        mycomm = new SqlCommand(q, myconn);
        mycomm.Parameters.AddWithValue("@n", TextBox1.Text);
        mycomm.Parameters.AddWithValue("@emid", TextBox2.Text);
        mycomm.Parameters.AddWithValue("@ph", TextBox3.Text);
        mycomm.Parameters.AddWithValue("@wo", RadioButtonList1.SelectedItem.Text);
        mycomm.Parameters.AddWithValue("@wd", RadioButtonList2.SelectedItem.Text);
        mycomm.Parameters.AddWithValue("@mr", RadioButtonList3.SelectedItem.Text);
        mycomm.Parameters.AddWithValue("@si", RadioButtonList4.SelectedItem.Text);
        mycomm.Parameters.AddWithValue("@sugg", TextBox4.Text);
        mycomm.Parameters.AddWithValue("@msgdt", DateTime.Now);
        myconn.Open();
        int res = mycomm.ExecuteNonQuery();
        myconn.Close();
        if (res == 1)
        {
            Label1.Text = "Thanks for submitting feedback";
        }
        else
        {
            Label1.Text = "some errors are occured";
        }
    }
}