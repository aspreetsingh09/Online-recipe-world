﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class updateproductdetails : System.Web.UI.Page
{
    string cid, scid;
    protected void Page_Load(object sender, EventArgs e)
    {
        if ((Page.IsPostBack) == false)
        {
            string pid = Request.QueryString["productid"];
            SqlConnection myconn;
            SqlCommand mycomm;
            myconn = new SqlConnection(ConfigurationManager.ConnectionStrings["cmd"].ConnectionString);
            string q = "select * from addproduct where productid=@pid";
            mycomm = new SqlCommand(q, myconn);
            mycomm.Parameters.AddWithValue("@pid", Request.QueryString["pid"]);
            myconn.Open();
            SqlDataReader myreader;
            myreader = mycomm.ExecuteReader();
            myreader.Read();
            TextBox1.Text = myreader["productname"].ToString();
            Editor1.Content = myreader["ingredients"].ToString();
            Editor2.Content = myreader["howtomake"].ToString();
            Image2.ImageUrl = "pics/" + myreader["productpic"].ToString();
            cid = myreader["maincatid"].ToString();
            scid = myreader["subcatid"].ToString();

            DropDownList1.SelectedValue = myreader["maincatid"].ToString();
            myconn.Close();
        }
    }
    protected void DropDownList1_DataBound(object sender, EventArgs e)
    {
        DropDownList1.Items.FindByValue(cid).Selected = true;
    }
    protected void DropDownList2_DataBound(object sender, EventArgs e)
    {
        DropDownList2.Items.FindByValue(scid).Selected = true;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
         SqlConnection myconn;
        SqlCommand mycomm;
        myconn = new SqlConnection(ConfigurationManager.ConnectionStrings["cmd"].ConnectionString);
        string q = "update addproduct set maincatid=@mcid,subcatid=@scid,productpic=@ppic,productname=@pname,ingredients=@ing,howtomake=@htm where productid=@pid";
        mycomm = new SqlCommand(q, myconn);
        mycomm.Parameters.AddWithValue("@mcid", DropDownList1.SelectedValue);
        mycomm.Parameters.AddWithValue("@scid", DropDownList2.SelectedValue);
         mycomm.Parameters.AddWithValue("@pname",TextBox1.Text);
         mycomm.Parameters.AddWithValue("@ing",Editor1.Content);
         mycomm.Parameters.AddWithValue("@htm", Editor2.Content);

        if (FileUpload1.HasFile == true)
        {
            mycomm.Parameters.AddWithValue("@ppic", FileUpload1.FileName);
            FileUpload1.SaveAs(MapPath("pics/" + FileUpload1.FileName));
          
        }
        else
        {
            mycomm.Parameters.AddWithValue("@ppic", Path.GetFileName(Image2.ImageUrl));
        }
        mycomm.Parameters.AddWithValue("@pid", Request.QueryString["pid"]);
        myconn.Open();
        int res = mycomm.ExecuteNonQuery();
        if (res == 1)
        {
            Label2.Text = "Recipe updated successfully";
        }
        else
        {
            Label2.Text = "some error occured,please try again";
        }
        myconn.Close();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("updateproduct.aspx");
    }
}

