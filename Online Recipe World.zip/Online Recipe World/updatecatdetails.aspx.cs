﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class updatecatdetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            SqlConnection myconn;
            SqlCommand mycomm;
            myconn = new SqlConnection(ConfigurationManager.ConnectionStrings["cmd"].ConnectionString);
            String q = "select * from addcat where catid=@catid";
            mycomm = new SqlCommand(q, myconn);
            mycomm.Parameters.AddWithValue("@catid", Request.QueryString["cid"]);
            myconn.Open();
            SqlDataReader myreader;
            myreader = mycomm.ExecuteReader();
            if (myreader.HasRows == true)
            {
                myreader.Read();
                TextBox1.Text = myreader["categoryname"].ToString();
                Image2.ImageUrl = "pics/" + myreader["categorypic"].ToString();
                myconn.Close();
            }
            myconn.Close();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
         SqlConnection myconn;
        SqlCommand mycomm;
        myconn = new SqlConnection(ConfigurationManager.ConnectionStrings["cmd"].ConnectionString);
        String q = "update addcat set categoryname=@cname,categorypic=@cpic where catid=@cid";
        mycomm = new SqlCommand(q, myconn);
        mycomm.Parameters.AddWithValue("@cname", TextBox1.Text);
        if(FileUpload1.HasFile==true)
        {
        mycomm.Parameters.AddWithValue("@cpic",FileUpload1.FileName);
            FileUpload1.SaveAs(MapPath("pics/"+FileUpload1.FileName));
            Image2.ImageUrl = "pics/" + FileUpload1.FileName;
        }
        else
        {
             mycomm.Parameters.AddWithValue("@cpic",Path.GetFileName(Image2.ImageUrl));
        }
         mycomm.Parameters.AddWithValue("@cid",Request.QueryString["cid"]);
          myconn.Open();
        int res = mycomm.ExecuteNonQuery();
        if (res == 1)
        {
            Label2.Text="category updated successfully";
        }
        else
        {
            Label2.Text = "Some error occured,Please try again";
        }
       myconn.Close();
    }
      protected void  Button2_Click(object sender, EventArgs e)
       {
         Response.Redirect("updatecat.aspx");
       }
}
    
