﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class updatesubcatdetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if ((Page.IsPostBack) == false)
        {
            SqlConnection myconn;
            SqlCommand mycomm;
            myconn = new SqlConnection(ConfigurationManager.ConnectionStrings["cmd"].ConnectionString);
            string q = "select * from addsubcat where subcatid=@scatid";
            mycomm = new SqlCommand(q, myconn);
            mycomm.Parameters.AddWithValue("@scatid", Request.QueryString["scid"]);
            myconn.Open();
            SqlDataReader myreader;
            myreader = mycomm.ExecuteReader();
            if (myreader.HasRows == true)
            {
                myreader.Read();
                TextBox1.Text = myreader["subcatname"].ToString();
                Image2.ImageUrl = "pics/" + myreader["subcatpic"].ToString();
                DropDownList1.SelectedValue = myreader["maincatid"].ToString();
                myconn.Close();
            }
            myconn.Close();
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection myconn;
        SqlCommand mycomm;
        myconn = new SqlConnection(ConfigurationManager.ConnectionStrings["cmd"].ConnectionString);
        string q = "update addsubcat set maincatid=@mcid,subcatname=@scname,subcatpic=@scpic where subcatid=@scid";
        mycomm = new SqlCommand(q, myconn);
        mycomm.Parameters.AddWithValue("@mcid", DropDownList1.SelectedValue);
        mycomm.Parameters.AddWithValue("@scname", TextBox1.Text);
        if (FileUpload1.HasFile == true)
        {
            mycomm.Parameters.AddWithValue("@scpic", FileUpload1.FileName);
            FileUpload1.SaveAs(MapPath("pics/" + FileUpload1.FileName));
            Image2.ImageUrl = "pics/" + FileUpload1.FileName;
        }
        else
        {
            mycomm.Parameters.AddWithValue("@scpic", Path.GetFileName(Image2.ImageUrl));
        }
        mycomm.Parameters.AddWithValue("@scid", Request.QueryString["scid"]);
        myconn.Open();
        int res = mycomm.ExecuteNonQuery();
        if (res == 1)
        {
            Label2.Text = "subcategory updated successfully";
        }
        else
        {
            Label2.Text = "some error occured,please try again";
        }
        myconn.Close();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("updatesubcat.aspx");
    }
}