﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;


public partial class productdetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            if (Session["uname"] != null)
            {
                Label7.Text = "";
                Panel2.Visible = true;
            }
            else
            {
                Label7.Text = "Please <a href='login.aspx?returnurl=productdetails.aspx?pid=" +  Request.QueryString["pid"] + "'>login</a> to comment";
                Panel2.Visible = false;
            }
        }
        string pid = Request["pid"];
        SqlConnection myconn;
        SqlCommand mycomm;
        myconn = new SqlConnection(ConfigurationManager.ConnectionStrings["cmd"].ConnectionString);
        string q = "select categoryname,subcatname,productname,ingredients,howtomake,productpic from addcat,addsubcat,addproduct where addproduct.maincatid=addcat.catid and addproduct.subcatid=addsubcat.subcatid and productid=@pid";
        mycomm = new SqlCommand(q, myconn);
        mycomm.Parameters.AddWithValue("@pid", pid);
        myconn.Open();
        SqlDataReader myreader;
        myreader = mycomm.ExecuteReader();
        myreader.Read();
        Label2.Text = myreader["categoryname"].ToString();
        Label3.Text = myreader["subcatname"].ToString();
        Label4.Text = myreader["productname"].ToString();
        Label5.Text = myreader["ingredients"].ToString();
        Label6.Text = myreader["howtomake"].ToString();
        ImageButton1.ImageUrl = "pics/" + myreader["productpic"].ToString();
        myconn.Close();
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("userpage.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        if (Session["uname"] != null)
        {
            string pid = Request["pid"];
            SqlConnection myconn;
            SqlCommand mycomm;
            myconn = new SqlConnection(ConfigurationManager.ConnectionStrings["cmd"].ConnectionString);
            string q = "insert into comment values(@comm,@commby,@commdt,@rid)";
            mycomm = new SqlCommand(q, myconn);
            mycomm.Parameters.AddWithValue("@comm", TextBox1.Text);
            mycomm.Parameters.AddWithValue("@commby", Session["n"].ToString());
            mycomm.Parameters.AddWithValue("@commdt", DateTime.Now);
            mycomm.Parameters.AddWithValue("@rid", Request.QueryString["pid"]);
            myconn.Open();
            int res = mycomm.ExecuteNonQuery();
            if (res == 1)
            {
                Response.Write("<script>alert('Comment Posted Successfully')</script>");
                DataList1.DataBind();
            }
            myconn.Close();
        }
        else
        {

        }
    }
    protected void SqlDataSource1_Selected(object sender, SqlDataSourceStatusEventArgs e)
    {
        Label8.Text = e.AffectedRows + " comment(s) on " + Label4.Text;
    }
}
