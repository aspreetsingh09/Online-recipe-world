﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class updatedetailsbyuser : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        string pid = Request["pid"];
        SqlConnection myconn;
        SqlCommand mycomm;
        myconn = new SqlConnection(ConfigurationManager.ConnectionStrings["cmd"].ConnectionString);
        string q = "select categoryname,subcatname,productname,ingredients,howtomake,productpic from addcat,addsubcat,addproductuser where addproductuser.maincatid=addcat.catid and addproductuser.subcatid=addsubcat.subcatid and productid=@pid";
        mycomm = new SqlCommand(q, myconn);
        mycomm.Parameters.AddWithValue("@pid", pid);
        myconn.Open();
        SqlDataReader myreader;
        myreader = mycomm.ExecuteReader();
        myreader.Read();
        Label2.Text = myreader["categoryname"].ToString();
        Label3.Text = myreader["subcatname"].ToString();
        Label4.Text = myreader["productname"].ToString();
        Label5.Text = myreader["ingredients"].ToString();
        Label6.Text = myreader["howtomake"].ToString();
        ImageButton1.ImageUrl = "pics/" + myreader["productpic"].ToString();
        myconn.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("userpage.aspx");
    }
}
